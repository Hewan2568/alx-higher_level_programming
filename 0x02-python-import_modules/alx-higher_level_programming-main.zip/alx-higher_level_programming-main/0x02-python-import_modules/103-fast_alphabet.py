#!/usr/bin/python3
import string
print(string.ascii_uppercase)
