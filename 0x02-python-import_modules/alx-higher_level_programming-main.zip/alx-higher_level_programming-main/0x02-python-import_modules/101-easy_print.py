#!/usr/bin/python3
import pythoniscool_101
